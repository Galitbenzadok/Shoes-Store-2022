import "./Menu.css";

function Menu(): JSX.Element {
    return (
        <div className="Menu">
            <br></br>
            <span>קישורים מומלצים:</span>
			<a href="#">דגמים חדשים</a>
			<a href="#">נעליים בעיצוב אישי</a>
			<a href="#">מבצעי סוף עונה</a>
        </div>
    );
}

export default Menu;
