import "./Header.css";


function Header(): JSX.Element {
    return (
        <div className="Header">
            <h1>חנות הנעליים המגניבה ביותר בארץ</h1>
        </div>
    );
}


export default Header;

