import Discount from "../Discount/Discount";
import MainVideo from "../MainVideo/MainVideo";

import "./Home.css";

function Home(): JSX.Element {
   

    return (
        <div className="Home">
            <Discount />
            <MainVideo />            
        </div>
    );
}


export default Home;
