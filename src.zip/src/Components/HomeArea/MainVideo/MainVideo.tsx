import "./MainVideo.css";


function MainVideo(): JSX.Element {
    return (
        <div className="MainVideo"> 
                   
            <br></br>			
            <iframe width="760" height="515" src="https://www.youtube.com/embed/3A41sd7poUQ"></iframe>              
        </div>
    );
}


export default MainVideo;
