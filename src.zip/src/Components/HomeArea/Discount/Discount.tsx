import "./Discount.css";

// Interpolation

function Discount(): JSX.Element {


    return (
        <div className="Discount Box">

            {isFirst() ? <span>הפסקה הזו תופיע רק אם היום הוא ה-1 בחודש.</span> : <span></span>}			

        </div>
    );
}

function isFirst(): boolean {
   const day = new Date().getDate();  
    console.log(day)  
    return day == 6;
}

export default Discount;
